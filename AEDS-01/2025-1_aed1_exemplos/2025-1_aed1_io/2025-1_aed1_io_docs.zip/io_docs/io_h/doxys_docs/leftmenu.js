function WriteLeftMenu(divID, aID, divClassName, aClassName)
{
document.write("<div id=\"divID0\" class=\"headerLeftMenuInActive\"><a id=\"aID0\" href=\"#\" OnMouseOver=\"link('','index',this)\" class=\"leftMenuLinkHeadInActive\">Default mainpage</a></div>\n");
document.write("<div id='leftmenutree' class='treeLeftMenu'>\n");
var treeLeftMenu = new TreeClass('treeLeftMenu', false);
treeLeftMenu.setTreeHeightDelta(-205);
treeLeftMenu.m_iDefaultExpandedLevel = 1;treeLeftMenu.setExpandCollapseNames('Expand All','Collapse All');
treeLeftMenu.startTree( true );
  treeLeftMenu.startParentNode('Default mainpage','"#"','','common/directoryBlue', { "onmouseover":"link('','index',this);" });
  treeLeftMenu.startParentNode('io_doc','"#"','','common/directoryBlue', { "onmouseover":"link('_dir','io_doc/io_doc0',this);" });
  treeLeftMenu.startParentNode('Functions','"#"','','common/functionsBlue');
  treeLeftMenu.addNode('IO_boolalpha','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_boolalpha56656',this);" });
  treeLeftMenu.addNode('IO_charAt','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_charAt973261875',this);" });
  treeLeftMenu.addNode('IO_check','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_check1268849199',this);" });
  treeLeftMenu.addNode('IO_clrscr','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_clrscr122',this);" });
  treeLeftMenu.addNode('IO_concat','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_concat35125896',this);" });
  treeLeftMenu.addNode('IO_debug','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_debug189218802',this);" });
  treeLeftMenu.addNode('IO_debugOFF','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_debugOFF122',this);" });
  treeLeftMenu.addNode('IO_debugON','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_debugON122',this);" });
  treeLeftMenu.addNode('IO_flush','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_flush122',this);" });
  treeLeftMenu.addNode('IO_fprint','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_fprint2467077857',this);" });
  treeLeftMenu.addNode('IO_fprintln','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_fprintln2467077857',this);" });
  treeLeftMenu.addNode('IO_fread','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_fread86128753',this);" });
  treeLeftMenu.addNode('IO_freadln','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_freadln86128753',this);" });
  treeLeftMenu.addNode('IO_id','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_id154236',this);" });
  treeLeftMenu.addNode('IO_length','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_length86138908',this);" });
  treeLeftMenu.addNode('IO_new_bools','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_new_bools60979',this);" });
  treeLeftMenu.addNode('IO_new_chars','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_new_chars60979',this);" });
  treeLeftMenu.addNode('IO_new_doubles','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_new_doubles60979',this);" });
  treeLeftMenu.addNode('IO_new_ints','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_new_ints60979',this);" });
  treeLeftMenu.addNode('IO_pause','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_pause154236',this);" });
  treeLeftMenu.addNode('IO_print','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_print154236',this);" });
  treeLeftMenu.addNode('IO_println','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_println154236',this);" });
  treeLeftMenu.addNode('IO_readbool','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_readbool154236',this);" });
  treeLeftMenu.addNode('IO_readchar','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_readchar154236',this);" });
  treeLeftMenu.addNode('IO_readdouble','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_readdouble154236',this);" });
  treeLeftMenu.addNode('IO_readfloat','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_readfloat154236',this);" });
  treeLeftMenu.addNode('IO_readint','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_readint154236',this);" });
  treeLeftMenu.addNode('IO_readln','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_readln154236',this);" });
  treeLeftMenu.addNode('IO_readstring','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_readstring154236',this);" });
  treeLeftMenu.addNode('IO_substring','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_substring2470015628',this);" });
  treeLeftMenu.addNode('IO_toString_b','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_toString_b56656',this);" });
  treeLeftMenu.addNode('IO_toString_c','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_toString_c49468',this);" });
  treeLeftMenu.addNode('IO_toString_d','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_toString_d60979',this);" });
  treeLeftMenu.addNode('IO_toString_f','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_toString_f86422002',this);" });
  treeLeftMenu.addNode('IO_version','"#"','','common/function', { "onmouseover":"link('_member','io_doc/IO_version122',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Defines','"#"','','common/definesBlue');
  treeLeftMenu.addNode('nullptr','"#"','','common/define', { "onmouseover":"link('_member','io_doc/nullptr339028536',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Attributes','"#"','','common/attributesBlue');
  treeLeftMenu.addNode('ENDL','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/ENDL0',this);" });
  treeLeftMenu.addNode('EOL','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/EOL0',this);" });
  treeLeftMenu.addNode('EOS','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/EOS0',this);" });
  treeLeftMenu.addNode('FALSE','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/FALSE0',this);" });
  treeLeftMenu.addNode('IO_error','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/IO_error0',this);" });
  treeLeftMenu.addNode('IO_trace','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/IO_trace0',this);" });
  treeLeftMenu.addNode('STR_EMPTY','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/STR_EMPTY0',this);" });
  treeLeftMenu.addNode('STR_SIZE','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/STR_SIZE0',this);" });
  treeLeftMenu.addNode('TRUE','"#"','','common/variable', { "onmouseover":"link('_member','io_doc/TRUE0',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Types','"#"','','common/typesBlue');
  treeLeftMenu.addNode('bools','"#"','','common/type', { "onmouseover":"link('_member','io_doc/bools0',this);" });
  treeLeftMenu.addNode('chars','"#"','','common/type', { "onmouseover":"link('_member','io_doc/chars0',this);" });
  treeLeftMenu.addNode('doubles','"#"','','common/type', { "onmouseover":"link('_member','io_doc/doubles0',this);" });
  treeLeftMenu.addNode('ints','"#"','','common/type', { "onmouseover":"link('_member','io_doc/ints0',this);" });
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endTree();
treeLeftMenu.readStateFromCookie();
document.write("</div>\n");
document.write("<div class=\"paragraphLeftMenu\">Miscellaneous</div>\n");
document.write("<div id=\"divID19\" class=\"leftMenuTreeInActive\"><a id=\"aID19\" href=\"#\" OnMouseOver=\"link('_statsindex','common/statistics/index',this)\" class=\"leftMenuLinkInActive\">Statistics</a></div>\n");
if(divID != "" && aID != "")
{
  var elemDiv = document.getElementById(divID);
  var elemA = document.getElementById(aID);
  if (elemDiv != undefined && elemA != undefined ) { // this is needed to abvoid crashing js on some memberpages 
    elemDiv.className = divClassName;
    elemA.className = aClassName;
  }
}
}

function WriteLeftMenu(divID, aID, divClassName, aClassName)
{
document.write("<div id=\"divID19\" class=\"headerLeftMenuInActive\"><a id=\"aID19\" href=\"#\" OnMouseOver=\"link('_statsindex','index',this)\" class=\"leftMenuLinkHeadInActive\">Statistics</a></div>\n");
document.write("<div id='leftmenutree' class='treeLeftMenu'>\n");
var treeLeftMenu = new TreeClass('treeLeftMenu', false);
treeLeftMenu.setTreeHeightDelta(-205);
treeLeftMenu.m_iDefaultExpandedLevel = 1;treeLeftMenu.setExpandCollapseNames('Expand All','Collapse All');
treeLeftMenu.startTree( true );
  treeLeftMenu.startParentNode('Default mainpage','"#"','','../directoryBlue', { "onmouseover":"link('','../../index',this);" });
  treeLeftMenu.startParentNode('io_doc','"#"','','../directoryBlue', { "onmouseover":"link('_dir','../../io_doc/io_doc0',this);" });
  treeLeftMenu.startParentNode('Functions','"#"','','../functionsBlue');
  treeLeftMenu.addNode('IO_boolalpha','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_boolalpha56656',this);" });
  treeLeftMenu.addNode('IO_charAt','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_charAt973261875',this);" });
  treeLeftMenu.addNode('IO_check','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_check1268849199',this);" });
  treeLeftMenu.addNode('IO_clrscr','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_clrscr122',this);" });
  treeLeftMenu.addNode('IO_concat','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_concat35125896',this);" });
  treeLeftMenu.addNode('IO_debug','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_debug189218802',this);" });
  treeLeftMenu.addNode('IO_debugOFF','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_debugOFF122',this);" });
  treeLeftMenu.addNode('IO_debugON','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_debugON122',this);" });
  treeLeftMenu.addNode('IO_flush','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_flush122',this);" });
  treeLeftMenu.addNode('IO_fprint','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_fprint2467077857',this);" });
  treeLeftMenu.addNode('IO_fprintln','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_fprintln2467077857',this);" });
  treeLeftMenu.addNode('IO_fread','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_fread86128753',this);" });
  treeLeftMenu.addNode('IO_freadln','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_freadln86128753',this);" });
  treeLeftMenu.addNode('IO_id','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_id154236',this);" });
  treeLeftMenu.addNode('IO_length','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_length86138908',this);" });
  treeLeftMenu.addNode('IO_new_bools','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_new_bools60979',this);" });
  treeLeftMenu.addNode('IO_new_chars','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_new_chars60979',this);" });
  treeLeftMenu.addNode('IO_new_doubles','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_new_doubles60979',this);" });
  treeLeftMenu.addNode('IO_new_ints','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_new_ints60979',this);" });
  treeLeftMenu.addNode('IO_pause','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_pause154236',this);" });
  treeLeftMenu.addNode('IO_print','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_print154236',this);" });
  treeLeftMenu.addNode('IO_println','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_println154236',this);" });
  treeLeftMenu.addNode('IO_readbool','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_readbool154236',this);" });
  treeLeftMenu.addNode('IO_readchar','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_readchar154236',this);" });
  treeLeftMenu.addNode('IO_readdouble','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_readdouble154236',this);" });
  treeLeftMenu.addNode('IO_readfloat','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_readfloat154236',this);" });
  treeLeftMenu.addNode('IO_readint','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_readint154236',this);" });
  treeLeftMenu.addNode('IO_readln','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_readln154236',this);" });
  treeLeftMenu.addNode('IO_readstring','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_readstring154236',this);" });
  treeLeftMenu.addNode('IO_substring','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_substring2470015628',this);" });
  treeLeftMenu.addNode('IO_toString_b','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_toString_b56656',this);" });
  treeLeftMenu.addNode('IO_toString_c','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_toString_c49468',this);" });
  treeLeftMenu.addNode('IO_toString_d','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_toString_d60979',this);" });
  treeLeftMenu.addNode('IO_toString_f','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_toString_f86422002',this);" });
  treeLeftMenu.addNode('IO_version','"#"','','../function', { "onmouseover":"link('_member','../../io_doc/IO_version122',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Defines','"#"','','../definesBlue');
  treeLeftMenu.addNode('nullptr','"#"','','../define', { "onmouseover":"link('_member','../../io_doc/nullptr339028536',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Attributes','"#"','','../attributesBlue');
  treeLeftMenu.addNode('ENDL','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/ENDL0',this);" });
  treeLeftMenu.addNode('EOL','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/EOL0',this);" });
  treeLeftMenu.addNode('EOS','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/EOS0',this);" });
  treeLeftMenu.addNode('FALSE','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/FALSE0',this);" });
  treeLeftMenu.addNode('IO_error','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/IO_error0',this);" });
  treeLeftMenu.addNode('IO_trace','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/IO_trace0',this);" });
  treeLeftMenu.addNode('STR_EMPTY','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/STR_EMPTY0',this);" });
  treeLeftMenu.addNode('STR_SIZE','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/STR_SIZE0',this);" });
  treeLeftMenu.addNode('TRUE','"#"','','../variable', { "onmouseover":"link('_member','../../io_doc/TRUE0',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Types','"#"','','../typesBlue');
  treeLeftMenu.addNode('bools','"#"','','../type', { "onmouseover":"link('_member','../../io_doc/bools0',this);" });
  treeLeftMenu.addNode('chars','"#"','','../type', { "onmouseover":"link('_member','../../io_doc/chars0',this);" });
  treeLeftMenu.addNode('doubles','"#"','','../type', { "onmouseover":"link('_member','../../io_doc/doubles0',this);" });
  treeLeftMenu.addNode('ints','"#"','','../type', { "onmouseover":"link('_member','../../io_doc/ints0',this);" });
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endTree();
treeLeftMenu.readStateFromCookie();
document.write("</div>\n");
document.write("<div class=\"paragraphLeftMenu\">Pages</div>\n");
document.write("<div id=\"divID69\" class=\"leftMenuTreeInActive\"><a id=\"aID69\" href=\"#\" OnMouseOver=\"link('_statsgeneral','stats_general',this)\" class=\"leftMenuLinkInActive\">General</a></div>\n");
document.write("<div id=\"divID70\" class=\"leftMenuTreeInActive\"><a id=\"aID70\" href=\"#\" OnMouseOver=\"link('_statsundoc','stats_undoc',this)\" class=\"leftMenuLinkInActive\">Undocumented</a></div>\n");
document.write("<div id=\"divID71\" class=\"leftMenuTreeInActive\"><a id=\"aID71\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_msg',this)\" class=\"leftMenuLinkInActive\">Msg-Messages</a></div>\n");
document.write("<div id=\"divID72\" class=\"leftMenuTreeInActive\"><a id=\"aID72\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_warn',this)\" class=\"leftMenuLinkInActive\">Msg-Warnings</a></div>\n");
document.write("<div id=\"divID73\" class=\"leftMenuTreeInActive\"><a id=\"aID73\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_err',this)\" class=\"leftMenuLinkInActive\">Msg-Errors</a></div>\n");
document.write("<div id=\"divID74\" class=\"leftMenuTreeInActive\"><a id=\"aID74\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_dbg',this)\" class=\"leftMenuLinkInActive\">Msg-Debug</a></div>\n");
if(divID != "" && aID != "")
{
  var elemDiv = document.getElementById(divID);
  var elemA = document.getElementById(aID);
  if (elemDiv != undefined && elemA != undefined ) { // this is needed to abvoid crashing js on some memberpages 
    elemDiv.className = divClassName;
    elemA.className = aClassName;
  }
}
}

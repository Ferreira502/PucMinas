function WriteLeftMenu(divID, aID, divClassName, aClassName)
{
document.write("<div id=\"divID19\" class=\"headerLeftMenuInActive\"><a id=\"aID19\" href=\"#\" OnMouseOver=\"link('_statsindex','index',this)\" class=\"leftMenuLinkHeadInActive\">Statistics</a></div>\n");
document.write("<div id='leftmenutree' class='treeLeftMenu'>\n");
var treeLeftMenu = new TreeClass('treeLeftMenu', false);
treeLeftMenu.setTreeHeightDelta(-205);
treeLeftMenu.m_iDefaultExpandedLevel = 1;treeLeftMenu.setExpandCollapseNames('Expand All','Collapse All');
treeLeftMenu.startTree( true );
  treeLeftMenu.startParentNode('Default mainpage','"#"','','../directoryBlue', { "onmouseover":"link('','../../index',this);" });
  treeLeftMenu.startParentNode('io_hpp','"#"','','../directoryBlue', { "onmouseover":"link('_dir','../../io_hpp/io_hpp0',this);" });
  treeLeftMenu.startParentNode('Functions','"#"','','../functionsBlue');
  treeLeftMenu.addNode('IO_boolalpha','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_boolalpha56656',this);" });
  treeLeftMenu.addNode('IO_charAt','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_charAt973261875',this);" });
  treeLeftMenu.addNode('IO_check','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_check1268849199',this);" });
  treeLeftMenu.addNode('IO_clrscr','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_clrscr53616',this);" });
  treeLeftMenu.addNode('IO_concat','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_concat2187277427',this);" });
  treeLeftMenu.addNode('IO_debug','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_debug3641852805',this);" });
  treeLeftMenu.addNode('IO_debugOFF','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_debugOFF122',this);" });
  treeLeftMenu.addNode('IO_debugON','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_debugON122',this);" });
  treeLeftMenu.addNode('IO_flush','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_flush53616',this);" });
  treeLeftMenu.addNode('IO_fprint','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_fprint4229503000',this);" });
  treeLeftMenu.addNode('IO_fprintln','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_fprintln4229503000',this);" });
  treeLeftMenu.addNode('IO_fread','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_fread86128753',this);" });
  treeLeftMenu.addNode('IO_freadln','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_freadln200265733',this);" });
  treeLeftMenu.addNode('IO_id','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_id140978785',this);" });
  treeLeftMenu.addNode('IO_length','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_length86138908',this);" });
  treeLeftMenu.addNode('IO_new_bools','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_new_bools60979',this);" });
  treeLeftMenu.addNode('IO_new_chars','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_new_chars60979',this);" });
  treeLeftMenu.addNode('IO_new_doubles','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_new_doubles60979',this);" });
  treeLeftMenu.addNode('IO_new_ints','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_new_ints60979',this);" });
  treeLeftMenu.addNode('IO_next','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_next140978785',this);" });
  treeLeftMenu.addNode('IO_nextLine','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_nextLine140978785',this);" });
  treeLeftMenu.addNode('IO_pause','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_pause140978785',this);" });
  treeLeftMenu.addNode('IO_print','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_print140978785',this);" });
  treeLeftMenu.addNode('IO_println','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_println140978785',this);" });
  treeLeftMenu.addNode('IO_readbool','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_readbool140978785',this);" });
  treeLeftMenu.addNode('IO_readchar','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_readchar140978785',this);" });
  treeLeftMenu.addNode('IO_readdouble','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_readdouble140978785',this);" });
  treeLeftMenu.addNode('IO_readfloat','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_readfloat140978785',this);" });
  treeLeftMenu.addNode('IO_readint','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_readint140978785',this);" });
  treeLeftMenu.addNode('IO_readln','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_readln140978785',this);" });
  treeLeftMenu.addNode('IO_readstring','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_readstring140978785',this);" });
  treeLeftMenu.addNode('IO_substring','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_substring2470015628',this);" });
  treeLeftMenu.addNode('IO_toString','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_toString140978785',this);" });
  treeLeftMenu.addNode('IO_version','"#"','','../function', { "onmouseover":"link('_member','../../io_hpp/IO_version53616',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Defines','"#"','','../definesBlue');
  treeLeftMenu.addNode('nullptr','"#"','','../define', { "onmouseover":"link('_member','../../io_hpp/nullptr374660040',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Attributes','"#"','','../attributesBlue');
  treeLeftMenu.addNode('ENDL','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/ENDL0',this);" });
  treeLeftMenu.addNode('EOL','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/EOL0',this);" });
  treeLeftMenu.addNode('EOS','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/EOS0',this);" });
  treeLeftMenu.addNode('FALSE','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/FALSE0',this);" });
  treeLeftMenu.addNode('IO_error','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/IO_error0',this);" });
  treeLeftMenu.addNode('IO_trace','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/IO_trace0',this);" });
  treeLeftMenu.addNode('STR_EMPTY','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/STR_EMPTY0',this);" });
  treeLeftMenu.addNode('STR_SIZE','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/STR_SIZE0',this);" });
  treeLeftMenu.addNode('TRUE','"#"','','../variable', { "onmouseover":"link('_member','../../io_hpp/TRUE0',this);" });
treeLeftMenu.endParentNode();
  treeLeftMenu.startParentNode('Types','"#"','','../typesBlue');
  treeLeftMenu.addNode('bools','"#"','','../type', { "onmouseover":"link('_member','../../io_hpp/bools0',this);" });
  treeLeftMenu.addNode('chars','"#"','','../type', { "onmouseover":"link('_member','../../io_hpp/chars0',this);" });
  treeLeftMenu.addNode('doubles','"#"','','../type', { "onmouseover":"link('_member','../../io_hpp/doubles0',this);" });
  treeLeftMenu.addNode('ints','"#"','','../type', { "onmouseover":"link('_member','../../io_hpp/ints0',this);" });
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endParentNode();
treeLeftMenu.endTree();
treeLeftMenu.readStateFromCookie();
document.write("</div>\n");
document.write("<div class=\"paragraphLeftMenu\">Pages</div>\n");
document.write("<div id=\"divID73\" class=\"leftMenuTreeInActive\"><a id=\"aID73\" href=\"#\" OnMouseOver=\"link('_statsgeneral','stats_general',this)\" class=\"leftMenuLinkInActive\">General</a></div>\n");
document.write("<div id=\"divID74\" class=\"leftMenuTreeInActive\"><a id=\"aID74\" href=\"#\" OnMouseOver=\"link('_statsundoc','stats_undoc',this)\" class=\"leftMenuLinkInActive\">Undocumented</a></div>\n");
document.write("<div id=\"divID75\" class=\"leftMenuTreeInActive\"><a id=\"aID75\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_msg',this)\" class=\"leftMenuLinkInActive\">Msg-Messages</a></div>\n");
document.write("<div id=\"divID76\" class=\"leftMenuTreeInActive\"><a id=\"aID76\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_warn',this)\" class=\"leftMenuLinkInActive\">Msg-Warnings</a></div>\n");
document.write("<div id=\"divID77\" class=\"leftMenuTreeInActive\"><a id=\"aID77\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_err',this)\" class=\"leftMenuLinkInActive\">Msg-Errors</a></div>\n");
document.write("<div id=\"divID78\" class=\"leftMenuTreeInActive\"><a id=\"aID78\" href=\"#\" OnMouseOver=\"link('_statsmsg','stats_msg_dbg',this)\" class=\"leftMenuLinkInActive\">Msg-Debug</a></div>\n");
if(divID != "" && aID != "")
{
  var elemDiv = document.getElementById(divID);
  var elemA = document.getElementById(aID);
  if (elemDiv != undefined && elemA != undefined ) { // this is needed to abvoid crashing js on some memberpages 
    elemDiv.className = divClassName;
    elemA.className = aClassName;
  }
}
}
